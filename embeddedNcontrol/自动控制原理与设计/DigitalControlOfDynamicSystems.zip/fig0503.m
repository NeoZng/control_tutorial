%  Figure 5.3      Digital Control of Dynamic Systems, 3e
%                  Franklin, Powell, Workman
%                  Addison-Wesley, Publishing Company, 1998
% Matlab 4.2 or 5.0

clear
clf
subplot(2,2,4), fig0503d
subplot(2,2,1), fig0503a
subplot(2,2,2), fig0503b
subplot(2,2,3), fig0503c
