%Bode grid yy by Kris Donhowe, SC Solutions, Inc.
h_axes = findobj(get(gcf,'Children'),'Type','axes');
grey = [0.7,0.7,0.7];

figpos = get(gcf,'Position');
pos_old = get(h_axes,'Position');
color_old = get(h_axes,'ycolor');
set(h_axes,'xcolor',grey,'ycolor',grey, ...
    'GridLineStyle','-','MinorGridLineStyle','-', ...
    'Units','pixels');

for i=1:length(h_axes)
    set(h_axes(i),'Position',[figpos(3:4) figpos(3:4)].*pos_old{i});
    axes(h_axes(i));
    grid on 
end

c=copyobj(h_axes,gcf); 
set(c,'color','none','xcolor','k',...
    'xgrid','off','ygrid','off'); 

for i=1:length(c)
    set(c(i),'ycolor',color_old{i});
end