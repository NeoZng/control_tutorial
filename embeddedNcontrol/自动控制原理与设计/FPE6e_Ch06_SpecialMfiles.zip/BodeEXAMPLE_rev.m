%Bode plot of FPE 6e Example 6.5 Figure 6.11, pages 313-314
%AEN + ACS 2/27/2007
%
% Magnitude plot with log magnitude on the left and db on the right
%
    warning off;
num=.01*[1 .01 1];
den=conv([1 0 0],[1/4 .02/2 1]);
[mag,phas,w]=bode(num,den);
magdb = 20*log10(mag);
    subplot(2,1,1);
[AX,H1,H2]=plotyy(w,mag(:),w,magdb,'loglog','semilogx');
set(get(AX(1),'Ylabel'),'string','Magnitude, |G|');
set(get(AX(2),'Ylabel'),'string','db');
xlabel('\omega');
title('Bode Magnitude');
grid on;
    subplot(2,1,2);
semilogx(w,phas);
xlabel('\omega');
ylabel('Phase, deg');
title('Bode Phase');
    warning on;
bodegridyy;